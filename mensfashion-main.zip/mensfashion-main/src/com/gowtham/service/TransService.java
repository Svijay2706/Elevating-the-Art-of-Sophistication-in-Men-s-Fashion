package com.gowtham.service;

public interface TransService {

	public String getUserId(String transId);
}
